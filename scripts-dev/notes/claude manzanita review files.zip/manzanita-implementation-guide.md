# Manzanita Theme Enhancement Guide
## Quick Implementation Roadmap

---

## Phase 1: Setup Build System (1 hour)

### Step 1: Create package.json
Create this file in the root of your Manzanita theme:

```json
{
  "name": "manzanita-theme",
  "version": "1.0.0",
  "description": "OSU CAS Subtheme based on Madrone",
  "scripts": {
    "build": "sass src/manzanita.scss:css/manzanita.css --style=compressed --no-source-map",
    "dev": "sass src/manzanita.scss:css/manzanita.css --watch --source-map",
    "watch": "npm run dev"
  },
  "devDependencies": {
    "sass": "^1.83.4"
  },
  "private": true
}
```

### Step 2: Install Dependencies
```bash
cd /path/to/manzanita
npm install
```

### Step 3: Test Build
```bash
npm run dev
```

**Result:** You can now build CSS without PhpStorm file watchers!

---

## Phase 2: Integrate CAS Colors (2 hours)

### Step 1: Update manzanita.scss

Replace your current `src/manzanita.scss` with:

```scss
// ============================================
// MANZANITA THEME - CAS Subtheme
// ============================================

// Import CAS color variables
@import './scss/cas_variables';

// ============================================
// TYPOGRAPHY CUSTOMIZATION
// ============================================

// Headings use CAS blue
h1, h2, h3, h4, h5, h6 {
  color: $osucas-blue;
}

h1 {
  font-size: 4rem;
  color: $osucas-candela;
}

// Links use CAS teal
a {
  color: $osucas-teal;
  
  &:hover {
    color: darken($osucas-teal, 15%);
  }
}

// ============================================
// CAS COMPONENT UTILITIES
// ============================================

// CAS Buttons
.btn-cas-primary {
  background-color: $osucas-teal;
  border-color: $osucas-teal;
  color: white;
  
  &:hover,
  &:focus {
    background-color: darken($osucas-teal, 10%);
    border-color: darken($osucas-teal, 10%);
    color: white;
  }
}

.btn-cas-secondary {
  background-color: $osucas-blue;
  border-color: $osucas-blue;
  color: white;
  
  &:hover,
  &:focus {
    background-color: darken($osucas-blue, 10%);
    border-color: darken($osucas-blue, 10%);
    color: white;
  }
}

.btn-cas-accent {
  background-color: $osucas-candela;
  border-color: $osucas-candela;
  color: $osucas-blue;
  
  &:hover,
  &:focus {
    background-color: darken($osucas-candela, 10%);
    border-color: darken($osucas-candela, 10%);
    color: $osucas-blue;
  }
}

// ============================================
// CAS BACKGROUND UTILITIES
// ============================================

.bg-cas-teal {
  background-color: $osucas-teal !important;
  color: white;
}

.bg-cas-blue {
  background-color: $osucas-blue !important;
  color: white;
}

.bg-cas-candela {
  background-color: $osucas-candela !important;
  color: $osucas-blue;
}

.bg-cas-pinestand {
  background-color: $osucas-pinestand !important;
  color: white;
}

.bg-cas-seafoam {
  background-color: $osucas-seafoam !important;
  color: $osucas-blue;
}

// ============================================
// CAS TEXT UTILITIES
// ============================================

.text-cas-teal {
  color: $osucas-teal !important;
}

.text-cas-blue {
  color: $osucas-blue !important;
}

.text-cas-candela {
  color: $osucas-candela !important;
}

// ============================================
// CAS BORDER UTILITIES
// ============================================

.border-cas-teal {
  border-color: $osucas-teal !important;
}

.border-cas-blue {
  border-color: $osucas-blue !important;
}

.border-cas-accent {
  border-color: $osucas-candela !important;
}

// Top border accent (common pattern)
.border-top-cas {
  border-top: 4px solid $osucas-candela;
}

// ============================================
// CAS CARDS
// ============================================

.card-cas {
  border-top: 3px solid $osucas-candela;
  
  .card-header {
    background-color: $osucas-teal;
    color: white;
    border-bottom: 2px solid darken($osucas-teal, 10%);
  }
}

// ============================================
// CAS ALERTS
// ============================================

.alert-cas {
  background-color: lighten($osucas-seafoam, 10%);
  border-left: 4px solid $osucas-teal;
  color: $osucas-blue;
}

.alert-cas-warning {
  background-color: lighten($osucas-luminance, 35%);
  border-left: 4px solid $osucas-luminance;
  color: darken($osucas-luminance, 40%);
}

// ============================================
// CAS HEADER/FOOTER
// ============================================

.cas-header {
  background: linear-gradient(135deg, $osucas-teal 0%, $osucas-blue 100%);
  color: white;
  padding: 2rem 0;
}

.cas-footer {
  background-color: $osucas-blue;
  color: white;
  padding: 3rem 0 2rem;
  
  a {
    color: $osucas-candela;
    
    &:hover {
      color: lighten($osucas-candela, 10%);
    }
  }
}

// ============================================
// CAS ACCENT SECTIONS
// ============================================

.section-cas-highlight {
  background-color: $osucas-seafoam;
  border-left: 5px solid $osucas-teal;
  padding: 2rem;
}

.section-cas-callout {
  background-color: lighten($osucas-candela, 35%);
  border: 2px solid $osucas-candela;
  padding: 2rem;
  margin: 2rem 0;
}
```

### Step 2: Build and Test
```bash
npm run build
```

**Result:** You now have CAS-branded utility classes available throughout your site!

---

## Phase 3: Documentation (2 hours)

### Create README.md

```markdown
# Manzanita Theme

OSU College of Agricultural Sciences (CAS) subtheme based on the Madrone theme.

## Quick Start

### Development Setup
```bash
npm install
npm run dev
```

### Building for Production
```bash
npm run build
```

## CAS Color Palette

### Primary Colors
- **CAS Teal** (`$osucas-teal`): #0d5257 - Primary brand color
- **CAS Blue** (`$osucas-blue`): #003b5c - Secondary brand color
- **CAS Candela** (`$osucas-candela`): #fdd26e - Accent/highlight color

### Utility Classes

#### Backgrounds
- `.bg-cas-teal` - CAS teal background
- `.bg-cas-blue` - CAS blue background
- `.bg-cas-candela` - CAS candela (yellow) background

#### Text Colors
- `.text-cas-teal` - CAS teal text
- `.text-cas-blue` - CAS blue text
- `.text-cas-candela` - CAS candela text

#### Buttons
- `.btn-cas-primary` - CAS teal button
- `.btn-cas-secondary` - CAS blue button
- `.btn-cas-accent` - CAS candela button

#### Cards
- `.card-cas` - Card with CAS styling

#### Borders
- `.border-cas-teal` - CAS teal border
- `.border-top-cas` - Top accent border (candela)

## File Structure

```
manzanita/
├── css/                    # Compiled CSS
├── src/                    # Source SCSS
│   ├── manzanita.scss     # Main stylesheet
│   └── scss/
│       └── _cas_variables.scss
├── templates/              # Template overrides
├── package.json
└── README.md
```

## Customization

### Adding New CAS Colors

1. Add to `src/scss/_cas_variables.scss`
2. Create utility classes in `src/manzanita.scss`
3. Build: `npm run build`

### Template Overrides

Place Twig template overrides in the `templates/` directory following Drupal naming conventions.

## Support

For questions about the Manzanita theme, contact the CAS web team.
For issues with the Madrone base theme, see the Madrone documentation.
```

### Create docs/colors.md

```markdown
# CAS Color Palette Guide

## Primary Palette

### CAS Teal (#0d5257)
**Usage:** Primary brand color
- Headers
- Primary buttons
- Navigation
- Links

**Accessibility:** ✅ WCAG AA compliant on white backgrounds

**Classes:**
- `.bg-cas-teal`
- `.text-cas-teal`
- `.border-cas-teal`
- `.btn-cas-primary`

---

### CAS Blue (#003b5c)
**Usage:** Secondary brand color
- Headings
- Secondary buttons
- Footer backgrounds

**Accessibility:** ✅ WCAG AA compliant on white backgrounds

**Classes:**
- `.bg-cas-blue`
- `.text-cas-blue`
- `.border-cas-blue`
- `.btn-cas-secondary`

---

### CAS Candela (#fdd26e)
**Usage:** Accent/highlight color
- Call-to-action elements
- Highlights
- Accent borders

**Accessibility:** ⚠️ Use dark text on this background

**Classes:**
- `.bg-cas-candela`
- `.text-cas-candela`
- `.border-cas-accent`
- `.btn-cas-accent`

## Extended Palette

### Nature-Inspired Colors
- **Pinestand** (#4a773c) - Forest green
- **Hightide** (#00859b) - Ocean blue
- **Seafoam** (#b8dde1) - Light blue-green
- **Reindeermoss** (#c4d6a4) - Light green

### Sky & Earth
- **Luminance** (#ffb500) - Bright yellow
- **Stratosphere** (#006a8e) - Sky blue
- **Moondust** (#c6dae7) - Pale blue
- **Till** (#b7a99a) - Earth tone

### Warm Tones
- **Hopbine** (#aa9d2e) - Gold
- **Solarflare** (#d3832b) - Orange
- **Starcanvas** (#003b5c) - Deep blue

### Neutrals
- **Coastline** (#a7aca2) - Gray-green
- **Highdesert** (#7a6855) - Tan
- **Crater** (#8e9089) - Gray

## Color Combinations

### Recommended Pairings
✅ **Teal + White** - High contrast, professional
✅ **Blue + Candela** - Bold, energetic
✅ **Seafoam + Teal** - Calm, approachable
✅ **White + Candela + Blue text** - Highlighted content

### Avoid
❌ **Candela + White text** - Poor contrast
❌ **Teal + Blue backgrounds** - Too similar
❌ **Multiple bright colors together** - Overwhelming

## Usage Examples

### Hero Section
```html
<div class="cas-header">
  <h1>Welcome to CAS</h1>
</div>
```

### Call-to-Action Button
```html
<a href="#" class="btn btn-cas-primary">Apply Now</a>
```

### Highlighted Card
```html
<div class="card card-cas">
  <div class="card-header">Featured Program</div>
  <div class="card-body">...</div>
</div>
```

### Alert Box
```html
<div class="alert alert-cas">
  Important information for CAS students
</div>
```
```

---

## Phase 4: Usage Examples (1 hour)

### Example 1: CAS Homepage Hero

```html
<!-- In your Twig template -->
<div class="cas-header text-center">
  <div class="container">
    <h1 class="display-3 mb-3">College of Agricultural Sciences</h1>
    <p class="lead mb-4">Cultivating the future of agriculture</p>
    <a href="/about" class="btn btn-cas-primary btn-lg me-2">Learn More</a>
    <a href="/apply" class="btn btn-cas-accent btn-lg">Apply Now</a>
  </div>
</div>
```

### Example 2: Featured Programs Section

```html
<section class="py-5">
  <div class="container">
    <h2 class="text-cas-blue text-center mb-5">Featured Programs</h2>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="card card-cas h-100">
          <div class="card-header">
            <h3 class="h5 mb-0">Sustainable Agriculture</h3>
          </div>
          <div class="card-body">
            <p>Leading research in sustainable farming practices...</p>
            <a href="/programs/sustainable-ag" class="btn btn-cas-secondary">
              Explore Program
            </a>
          </div>
        </div>
      </div>
      <!-- More cards... -->
    </div>
  </div>
</section>
```

### Example 3: Important Announcement

```html
<div class="container my-4">
  <div class="alert alert-cas" role="alert">
    <h4 class="alert-heading text-cas-teal">Spring Registration Open</h4>
    <p>Register for spring semester courses now through November 30.</p>
    <hr>
    <a href="/register" class="btn btn-cas-primary btn-sm">Register Now</a>
  </div>
</div>
```

---

## Testing Checklist

### After Implementation, Test:

- [ ] Build system works (`npm run dev`, `npm run build`)
- [ ] All CAS colors display correctly
- [ ] Button styles work and are accessible
- [ ] Cards render with CAS styling
- [ ] Typography looks good (headings, links)
- [ ] Mobile responsive (test on phone)
- [ ] Color contrast meets WCAG AA
- [ ] No console errors
- [ ] CSS file size is reasonable (< 50KB)

### Browser Testing
- [ ] Chrome
- [ ] Firefox
- [ ] Safari
- [ ] Edge
- [ ] Mobile Safari (iOS)
- [ ] Mobile Chrome (Android)

---

## Common Issues & Solutions

### Issue: Colors not showing
**Solution:** Clear Drupal cache: `drush cr`

### Issue: Old CSS still loading
**Solution:** 
1. Hard refresh (Ctrl+Shift+R)
2. Clear browser cache
3. Check CSS file timestamp

### Issue: Build command not found
**Solution:** Run `npm install` first

### Issue: File watcher conflicts
**Solution:** Disable PhpStorm file watcher, use `npm run dev` instead

---

## Next Steps

### Immediate (This Week)
1. Implement Phase 1-3 above
2. Test on staging site
3. Get feedback from CAS team

### Short-term (Next 2 Weeks)
1. Add template overrides as needed
2. Create more component styles
3. Document any custom patterns

### Long-term (Next Month)
1. Performance optimization
2. Accessibility audit
3. Style guide website

---

## Resources

### Documentation
- [Drupal Theming Guide](https://www.drupal.org/docs/theming-drupal)
- [Bootstrap 5 Documentation](https://getbootstrap.com/docs/5.2/)
- [Sass Documentation](https://sass-lang.com/documentation)

### Tools
- [WebAIM Contrast Checker](https://webaim.org/resources/contrastchecker/)
- [Coolors.co](https://coolors.co/) - Color palette generator
- [ColorZilla](https://www.colorzilla.com/) - Browser color picker

### OSU Resources
- Madrone Theme Documentation (if available)
- OSU Brand Guidelines
- CAS Brand Guidelines

---

## Contact

For questions or support:
- **Theme Issues:** [Your contact info]
- **CAS Branding:** [CAS marketing contact]
- **Technical Support:** [IT contact]

---

*Last Updated: February 13, 2026*
