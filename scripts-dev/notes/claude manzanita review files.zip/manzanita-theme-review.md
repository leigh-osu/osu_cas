# Manzanita Subtheme Review & Comparison

## Executive Summary

**Manzanita** is a minimal Drupal subtheme that extends **Madrone** for the OSU College of Agricultural Sciences (CAS). It follows the lightweight subtheme pattern, inheriting most functionality from Madrone while providing CAS-specific customizations.

---

## Subtheme Structure

### File Organization 📁

```
manzanita/
├── css/                       # Compiled CSS
│   ├── manzanita.css         # 4 lines of CSS
│   └── manzanita.css.map
├── src/                       # Source files
│   ├── manzanita.scss        # Main SCSS (7 lines)
│   └── scss/
│       └── _cas_variables.scss  # CAS color palette
├── templates/                 # Empty (inherits from Madrone)
├── logo.svg
├── manzanita.info.yml        # Theme definition
└── manzanita.libraries.yml   # Library definition
```

**Key Characteristics:**
- ✅ **Extremely lightweight** - Only 7 lines of custom SCSS
- ✅ **Clean inheritance** - Properly extends Madrone base theme
- ✅ **Department-specific** - CAS color palette customization
- ⚠️ **Minimal customization** - Currently underutilized

---

## Theme Configuration Analysis

### manzanita.info.yml ✅

```yaml
name: Manzanita
description: 'OSU CAS Subtheme based on OSU Madrone theme'
base theme: madrone
dependencies:
  - madrone:madrone
```

**Observations:**
- ✅ Correctly declares Madrone as base theme
- ✅ Proper dependency declaration
- ✅ Supports Drupal 10 & 11
- ✅ Inherits all Madrone regions (header, footer, sidebar, etc.)
- ✅ Smart library loading from Madrone:
  - `madrone/fonts` - Stratum2Web font family
  - `madrone/bootstrap` - Bootstrap 5.2 framework
  - `madrone/global-styling` - All Madrone components

### manzanita.libraries.yml ✅

```yaml
global-styling:
  css:
    base:
      css/manzanita.css: { }
  dependencies:
    - core/drupal
    - core/jquery
    - core/once
```

**Observations:**
- ✅ Minimal CSS override approach
- ✅ Proper core dependencies
- 💡 JavaScript file commented out (not needed yet)

---

## SCSS Architecture

### Current Implementation

**manzanita.scss** (7 lines):
```scss
@import './scss/cas_variables';

h1 {
  font-size: 4rem;
  color: $osucas-candela;
}
```

**Compiled Output** (4 lines):
```css
h1 {
  font-size: 4rem;
  color: #fdd26e;
}
```

### CAS Color Palette 🎨

The `_cas_variables.scss` file defines **22 CAS-specific colors**:

**Primary Colors:**
- `$osucas-teal` - #0d5257 (appears to be primary brand color)
- `$osucas-blue` - #003b5c
- `$osu-orange` - #d73f09 (OSU main brand orange)

**Extended Palette:**
- Pinestand, Hightide, Luminance, Stratosphere
- Reindeermoss, Seafoam, Candela, Moondust
- Hopbine, Roguewave, Solarflare, Starcanvas
- Till, Coastline, Highdesert, Crater

**Current Status:** ⚠️
- Variables are defined but **NOT UTILIZED**
- Only `$osucas-candela` is used (h1 color)
- 21 other colors are unused
- Variables are not integrated with Bootstrap/Madrone

---

## Relationship to Madrone Theme

### Inheritance Model ✅

**What Manzanita Inherits from Madrone:**
1. **All SCSS/CSS:**
   - Bootstrap 5.2 framework
   - 31 component styles
   - Layout system
   - Utility classes
   - Typography (Stratum2Web fonts)

2. **All JavaScript:**
   - Bootstrap bundle
   - Custom Madrone scripts
   - Message handling
   - Editoria11y integration

3. **All Templates:**
   - Complete template system (309KB of templates)
   - Block, content, form, layout templates
   - Views templates
   - Media library templates

4. **Configuration:**
   - Region definitions
   - Breakpoints
   - Theme settings

**What Manzanita Customizes:**
- 🎨 H1 typography (larger size, CAS color)
- 🎨 CAS color palette (defined but unused)
- 🖼️ Logo (custom CAS logo)

### CSS Cascade 📊

**Load Order:**
1. Madrone fonts library
2. Madrone Bootstrap library (~391KB CSS)
3. Madrone global-styling library
4. **Manzanita global-styling (4 lines)** ← Overrides

**Total CSS Footprint:**
- Madrone: ~391KB
- Manzanita: ~0.5KB
- **Combined: ~391.5KB**

---

## Comparison: Madrone vs. Manzanita

### Architecture Comparison

| Aspect | Madrone (Base) | Manzanita (Subtheme) |
|--------|----------------|----------------------|
| **Purpose** | University-wide theme | CAS department theme |
| **SCSS Files** | 50+ files | 2 files |
| **CSS Output** | 391KB | 0.5KB |
| **Components** | 31 components | 0 components (inherits) |
| **Templates** | 309KB templates | 0 (inherits all) |
| **Build System** | Gulp | Manual/PhpStorm watcher |
| **Customization** | Full framework | Minimal overrides |
| **Target** | All OSU sites | CAS-specific sites |

### Design System Comparison

**Madrone Color System:**
- OSU official colors
- Bootstrap theme colors
- Utility color classes
- Custom color maps

**Manzanita Color System:**
- CAS-specific palette (22 colors)
- Defined but not integrated
- Single color usage (h1)

**Recommendation:** 🎯
CAS colors should be integrated into Bootstrap's color system for consistency.

---

## Current State Assessment

### Strengths ✅

1. **Proper Subtheme Pattern:**
   - Clean inheritance from Madrone
   - No duplication of code
   - Minimal footprint

2. **Smart Library Loading:**
   - Inherits all Madrone functionality
   - Only loads custom overrides

3. **Department Branding:**
   - CAS-specific color palette defined
   - Custom logo
   - Department identification

4. **PhpStorm Integration:**
   - File watcher successfully configured
   - Automatic SCSS compilation working

### Weaknesses ⚠️

1. **Underutilized Potential:**
   - 22 CAS colors defined but only 1 used
   - No CAS-specific components
   - No template overrides
   - Minimal styling customization

2. **No Build System:**
   - Relies on PhpStorm file watcher
   - No npm scripts
   - No package.json for dependencies
   - No version control for build tools

3. **Limited Documentation:**
   - No README
   - No setup instructions
   - No color palette documentation
   - No design guidelines

4. **Missed Opportunities:**
   - Not leveraging Bootstrap customization
   - CAS colors not in utility classes
   - No responsive customizations
   - No accessibility enhancements

---

## Integration Issues & Concerns

### Color Palette Integration ⚠️

**Current State:**
```scss
// Defined in Manzanita
$osucas-teal: #0d5257;

// Used once
h1 {
  color: $osucas-candela;
}
```

**Problem:**
- CAS colors are isolated in Manzanita
- Not available in Bootstrap utilities
- Can't use `.bg-osucas-teal` or `.text-osucas-blue`
- No integration with Madrone's color system

**Solution Needed:**
```scss
// Should integrate with Bootstrap
$theme-colors: (
  "cas-teal": $osucas-teal,
  "cas-blue": $osucas-blue,
  // etc.
);
```

### Build Process Gap 🔧

**Current Workflow:**
1. Edit `.scss` file in PhpStorm
2. File watcher triggers
3. Sass compiles to CSS
4. Manual refresh needed

**Issues:**
- No linting
- No minification
- No autoprefixer
- No source maps in production
- No CSS purging
- Team members need to configure file watchers individually

---

## Recommendations

### Immediate Priorities 🔴

#### 1. Integrate CAS Color Palette
```scss
// manzanita.scss
@import './scss/cas_variables';

// Integrate with Bootstrap BEFORE Madrone imports
$theme-colors: map-merge(
  $theme-colors,
  (
    'cas-teal': $osucas-teal,
    'cas-blue': $osucas-blue,
    'cas-candela': $osucas-candela,
    // Add other key colors
  )
);

// This would enable:
// .btn-cas-teal
// .bg-cas-blue
// .text-cas-candela
```

**Impact:** 🎨
- Makes CAS colors available throughout the site
- Enables utility classes for editors
- Consistent color usage
- Better brand integration

#### 2. Add Build System
Create `package.json`:
```json
{
  "name": "manzanita-theme",
  "version": "1.0.0",
  "scripts": {
    "build": "sass src/manzanita.scss:css/manzanita.css --style=compressed",
    "watch": "sass src/manzanita.scss:css/manzanita.css --watch",
    "dev": "sass src/manzanita.scss:css/manzanita.css --watch --source-map"
  },
  "devDependencies": {
    "sass": "^1.83.4"
  }
}
```

**Benefits:**
- ✅ Consistent builds across team
- ✅ No PhpStorm-specific setup
- ✅ CI/CD ready
- ✅ Production minification

#### 3. Create Documentation
Add `README.md`:
```markdown
# Manzanita Theme

OSU College of Agricultural Sciences subtheme of Madrone.

## Quick Start
npm install
npm run watch

## Color Palette
[Document CAS colors with visual swatches]

## Development
[Setup instructions]
```

### Short-term Enhancements 🟡

#### 4. Typography Customization
```scss
// Define CAS-specific typography
h1, h2, h3 {
  color: $osucas-blue;
}

.cas-header {
  background: $osucas-teal;
  color: white;
}

.cas-accent {
  border-left: 4px solid $osucas-candela;
}
```

#### 5. Component Overrides
Create CAS-specific component styles:
```scss
// src/scss/components/_cas_buttons.scss
.btn-cas-primary {
  background: $osucas-teal;
  border-color: $osucas-teal;
  &:hover {
    background: darken($osucas-teal, 10%);
  }
}

// src/scss/components/_cas_cards.scss
.card-cas {
  border-top: 3px solid $osucas-candela;
}
```

#### 6. Add Template Overrides
Create CAS-specific templates when needed:
```
templates/
├── block/
│   └── block--system-branding-block.html.twig  # Custom CAS header
├── layout/
│   └── page.html.twig  # CAS-specific layout
└── content/
    └── node--article.html.twig  # CAS article styling
```

### Long-term Improvements 🟢

#### 7. Design System Documentation
- Create style guide showing CAS color usage
- Document typography scale
- Component examples
- Accessibility guidelines

#### 8. Performance Optimization
- Critical CSS extraction
- Unused CSS purging (may not need all 31 Madrone components)
- Lazy load non-critical components

#### 9. Testing Infrastructure
- Visual regression testing
- Accessibility testing
- Cross-browser testing

---

## Proposed File Structure

### Expanded Manzanita Structure
```
manzanita/
├── css/
│   ├── manzanita.css
│   └── manzanita.css.map
├── src/
│   ├── manzanita.scss              # Main entry point
│   └── scss/
│       ├── _cas_variables.scss     # Color palette
│       ├── abstracts/
│       │   └── _cas_mixins.scss    # CAS-specific mixins
│       ├── components/              # CAS component overrides
│       │   ├── _cas_buttons.scss
│       │   ├── _cas_cards.scss
│       │   └── _cas_header.scss
│       └── utilities/
│           └── _cas_utilities.scss # CAS utility classes
├── templates/                       # Template overrides as needed
├── docs/
│   ├── README.md
│   ├── colors.md                   # Color palette guide
│   └── components.md               # Component usage
├── package.json                    # Build dependencies
├── logo.svg
├── manzanita.info.yml
└── manzanita.libraries.yml
```

---

## Enhanced SCSS Architecture Proposal

### Recommended manzanita.scss Structure

```scss
// ============================================
// MANZANITA THEME - CAS Subtheme
// ============================================

// 1. CAS Variables (before Madrone)
@import './scss/cas_variables';
@import './scss/abstracts/cas_mixins';

// 2. Integrate CAS colors with Bootstrap
// This makes CAS colors available as utility classes
$theme-colors: map-merge(
  $theme-colors,
  (
    'cas-primary': $osucas-teal,
    'cas-secondary': $osucas-blue,
    'cas-accent': $osucas-candela,
    'cas-success': $osucas-pinestand,
    'cas-info': $osucas-stratosphere,
    'cas-warning': $osucas-luminance,
  )
);

// 3. Typography Overrides
$headings-color: $osucas-blue;
$link-color: $osucas-teal;

// 4. Component Customizations
@import './scss/components/cas_buttons';
@import './scss/components/cas_cards';
@import './scss/components/cas_header';

// 5. Utility Classes
@import './scss/utilities/cas_utilities';

// 6. Page-specific Styles
@import './scss/pages/cas_home';
```

---

## CAS Color Palette Documentation

### Recommended Usage Guidelines

**Primary Palette** (Most Used):
- `$osucas-teal` (#0d5257) - Primary brand color
  - Use for: headers, primary buttons, links
- `$osucas-blue` (#003b5c) - Secondary brand
  - Use for: headings, accents
- `$osucas-candela` (#fdd26e) - Accent/highlight
  - Use for: CTAs, highlights, warnings

**Supporting Colors:**
- `$osucas-pinestand` (#4a773c) - Success states
- `$osucas-luminance` (#ffb500) - Attention/warning
- `$osucas-seafoam` (#b8dde1) - Light accents

**Neutral Palette:**
- `$osucas-gray` (#8e9089)
- `$osucas-light-gray` (#ddd)
- `$osucas-crater` (#8e9089)

### Accessibility Considerations ♿

**Color Contrast Ratios Needed:**
```scss
// Verify these combinations meet WCAG AA (4.5:1)
// Dark text on light backgrounds
.text-on-light {
  color: $osucas-blue;      // Check contrast
  background: white;
}

// Light text on dark backgrounds
.text-on-dark {
  color: white;
  background: $osucas-teal; // Check contrast
}
```

**Recommendation:** Run all CAS colors through a contrast checker before deployment.

---

## Migration Path: Current → Enhanced

### Phase 1: Foundation (Week 1)
1. ✅ Add package.json with build scripts
2. ✅ Document color palette
3. ✅ Create README.md
4. ✅ Integrate CAS colors with Bootstrap

### Phase 2: Components (Weeks 2-3)
1. Create button overrides
2. Card component customization
3. Header/footer CAS styling
4. Form element styling

### Phase 3: Templates (Week 4)
1. Identify needed template overrides
2. Create CAS-specific templates
3. Test template inheritance

### Phase 4: Polish (Week 5)
1. Accessibility audit
2. Performance optimization
3. Cross-browser testing
4. Documentation completion

---

## Risk Assessment

### Low Risk ✅
- Adding build system (non-breaking)
- Documentation (additive)
- Color integration (extends existing)

### Medium Risk ⚠️
- Template overrides (may affect updates)
- Component customizations (CSS specificity)
- Bootstrap variable changes (inheritance)

### Mitigation Strategies
1. **Version Control:** Commit before major changes
2. **Testing:** Test on staging before production
3. **Documentation:** Document all overrides
4. **Madrone Updates:** Monitor for conflicts

---

## Key Insights & Observations

### What's Working Well ✅
1. **Clean Subtheme Pattern:** Proper Drupal inheritance
2. **Minimal Footprint:** No unnecessary code duplication
3. **Clear Purpose:** Department-specific branding
4. **File Watcher:** Successful SCSS compilation setup

### What Needs Improvement ⚠️
1. **Underutilized Assets:** 22 colors defined, only 1 used
2. **No Build System:** Team coordination issues
3. **Missing Documentation:** Setup and usage unclear
4. **Limited Customization:** Not leveraging subtheme potential

### Strategic Questions 🤔
1. **How different should CAS look from main OSU?**
   - Minimal difference (current state)
   - Moderate customization (recommended)
   - Completely different design (not recommended for subtheme)

2. **What components need CAS-specific styling?**
   - Buttons? Headers? Cards? Forms?
   - Event calendars? News listings?

3. **Are CAS-specific templates needed?**
   - Custom homepage layout?
   - Department-specific content types?

4. **Should Manzanita have its own design system?**
   - Document CAS color usage
   - Create component library
   - Establish design patterns

---

## Comparison Summary

### Size Comparison
- **Madrone:** 3.3MB total, 391KB CSS, 50+ SCSS files
- **Manzanita:** 41KB total, 0.5KB CSS, 2 SCSS files
- **Ratio:** Manzanita is 1.2% the size of Madrone

### Complexity Comparison
- **Madrone:** Full-featured theme framework
- **Manzanita:** Minimal override layer

### Maintenance Comparison
- **Madrone:** High complexity, requires Gulp, npm, testing
- **Manzanita:** Low complexity, file watcher sufficient *currently*

---

## Final Recommendations Priority Matrix

### Must Do (High Impact, Low Effort) 🔴
1. **Integrate CAS colors with Bootstrap** (2 hours)
2. **Add package.json build system** (1 hour)
3. **Create README documentation** (2 hours)

### Should Do (High Impact, Medium Effort) 🟡
4. **Add component overrides** (1 week)
5. **Typography customization** (2 days)
6. **Color palette documentation** (1 day)

### Could Do (Medium Impact, Various Effort) 🟢
7. **Template overrides** (as needed)
8. **Design system documentation** (1 week)
9. **Performance optimization** (3 days)

### Future Consideration (Low Priority) ⚪
10. **Advanced build pipeline** (1 week)
11. **Testing infrastructure** (2 weeks)
12. **CI/CD integration** (3 days)

---

## Conclusion

**Current State:**
Manzanita is a well-structured but underutilized subtheme. It properly inherits from Madrone but only scratches the surface of customization potential.

**Recommended Direction:**
Enhance Manzanita with CAS-specific styling while maintaining the lightweight subtheme approach. Focus on color integration, component customization, and documentation.

**Success Metrics:**
- ✅ CAS color palette fully integrated and documented
- ✅ Build system enables team collaboration
- ✅ 5-10 CAS-specific component overrides
- ✅ Clear documentation for developers and content editors
- ✅ Maintains performance (keep CSS under 50KB additional)

**Timeline:**
With focused effort, Manzanita could be fully enhanced in 4-5 weeks while maintaining stability and inheritance from Madrone.

---

*Review Date: February 13, 2026*
*Themes Reviewed: Madrone (base) and Manzanita (subtheme)*
