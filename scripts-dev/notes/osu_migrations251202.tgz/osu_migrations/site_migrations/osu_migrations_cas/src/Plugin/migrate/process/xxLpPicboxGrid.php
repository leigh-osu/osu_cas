<?php

namespace Drupal\osu_migrations_cas\Plugin\migrate\process;

use Drupal\Component\Uuid\UuidInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\migrate\Annotation\MigrateProcessPlugin;
use Drupal\migrate\MigrateExecutableInterface;
use Drupal\migrate\MigrateLookupInterface;
use Drupal\migrate\Plugin\MigrationInterface;
use Drupal\migrate\Row;
use Drupal\osu_migrations\OsuMediaEmbed;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\osu_migrations_cas\CasLayoutBase;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Custom plugin for handling paragraph lp_picbox_grid items from d7.
 *
 * @MigrateProcessPlugin(
 *   id = "lp_picbox_grid",
 *   handle_multiples = TRUE
 * )
 */
class xxLpPicboxGrid extends CasLayoutBase {

  /**
   * The OSU Media Embed Service.
   *
   * @var \Drupal\osu_migrations\OsuMediaEmbed
   */
  private OsuMediaEmbed $osuMediaEmbed;

  /**
   * {@inheritDoc}
   */
  public function __construct(array $configuration, $pluginId, $pluginDefinition, UuidInterface $uuid, Connection $db, EntityTypeManagerInterface $entityTypeManager, ConfigFactoryInterface $configFactory, MigrateLookupInterface $migrateLookup, OsuMediaEmbed $osuMediaEmbed) {
    parent::__construct($configuration, $pluginId, $pluginDefinition, $uuid, $db, $entityTypeManager, $configFactory, $migrateLookup);
    $this->osuMediaEmbed = $osuMediaEmbed;
  }

  /**
   * {@inheritDoc}
   */
  public function transform($value, MigrateExecutableInterface $migrate_executable, Row $row, $destination_property) {
    $picboxGridParagraph = $value[0];
    if (!empty($picboxGridParagraph)) {


      $d7_picbox_grid_items = $this->getPicboxGridItems($picboxGridItemIds);

      // Create picbox items using title and body from d7.
      $paragraph_items = [];
      foreach ($d7_picbox_grid_items as $picbox_grid_item) {
        // Get the current value.
        $bodyValue = $picbox_grid_item->field_lp_picbox_box_description_value;
        // Pass it to our service to get the new embed value.
        $transformedEmbedCode = $this->osuMediaEmbed->transformEmbedCode($bodyValue);
        $body_format = (isset($vertical_tab->field_lp_picbox_box_description_format)) ? $vertical_tab->field_lp_picbox_box_description_format : "full_html";
        if ($body_format == 'filtered_html'){
          $body_format = 'basic_html';
        }

        $paragraph_items[] = Paragraph::create([
          'type' => 'osu_accordion_item',
          'field_p_accordion_title' => $vertical_tab->field_lp_vert_tab_title_value,
          'field_p_accordion_body' => [
            'value' => $transformedEmbedCode,
            'format' => $body_format,
          ],
        ]);
      }

      // Create accordion section and attach accordion items.
      $paragraph_section = Paragraph::create([
        'type' => 'osu_accordion_section',
        'field_p_accordion_heading' => '',
        'field_osu_paragraph_item' => $paragraph_items,
      ]);
      $block = Block::create([
        'plugin' => 'system_menu_block:devel',
        'region' => 'sidebar_first',
        'id' => $block_id,
        'theme' => $this->config('system.theme')->get('default'),
        'label' => $this->randomMachineName(8),
        'visibility' => [],
        'weight' => 0,
      ]);
      $block->save();
      // Return accordion section which gets attached to the block created by the
      // migration.
      return $paragraph_section;
    }
    return $value;
  }

  /**
   * Query Migration source database for all Paragraph Accordion Bundles.
   *
   * @param mixed $value
   *   The id of the paragraph.
   *
   * @return \Drupal\Core\Database\StatementInterface|null
   *   A prepared statement, or NULL if the query is not valid.
   */
  private function getPicboxGridItems($value) {
    $entity_ids = [];
    $revision_ids = [];
    foreach ($value as $id) {
      $entity_ids[] = $id['value'];
      $revision_ids[] = $id['revision_id'];
    }

    $query = $this->migrateDb->select('field_data_field_lp_picbox_box_headline', 'headline');
    $query->leftJoin(
      'field_lp_picbox_box_description',
      'description',
      'headline.entity_id = description.entity_id && headline.revision_id = description.revision_id'
    );
    $query->leftJoin(
      'field_lp_picbox_box_image',
      'image',
      'headline.entity_id = image.entity_id && headline.revision_id = image.revision_id'
    );
    $query->leftJoin(
      'field_lp_picbox_box_link_url',
      'link',
      'headline.entity_id = link.entity_id && headline.revision_id = link.revision_id'
    );
    $query->leftJoin(
      'field_paragraph_label',
      'label',
      'headline.entity_id = label.entity_id && headline.revision_id = label.revision_id'
    );
    $query->fields('headline', ['field_lp_picbox_box_headline_value']);
    $query->fields('link', ['field_lp_picbox_box_link_url']);
    $query->fields('image', ['field_lp_picbox_box_image_fid']);
    $query->fields('description', ['field_lp_picbox_box_description_value']);
    $query->fields('description', ['field_lp_picbox_box_description_format']);
    $query->fields('label', ['field_paragraph_label_value']);
    $query->condition('title.entity_id', $entity_ids, 'IN');
    $query->condition('title.revision_id', $revision_ids, 'IN');
    return $query->execute();
  }

  /**
   * {@inheritDoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition, ?MigrationInterface $migration = NULL) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('uuid'),
      $container->get('database'),
      $container->get('entity_type.manager'),
      $container->get('config.factory'),
      $container->get('migrate.lookup'),
      $container->get('osu_migrations.osu_media_embed')
    );
  }

}
