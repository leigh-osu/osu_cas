<?php

namespace Drupal\osu_migrations_cas\Plugin\migrate\process;

use Drupal\Component\Uuid\UuidInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\migrate\Annotation\MigrateProcessPlugin;
use Drupal\migrate\MigrateExecutableInterface;
use Drupal\migrate\MigrateLookupInterface;
use Drupal\migrate\Plugin\MigrationInterface;
use Drupal\migrate\Row;
use Drupal\osu_migrations\OsuMediaEmbed;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\osu_migrations_cas\CasLayoutBase;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Custom plugin for handling paragraph lp_adjustable_tabs items from d7.
 *
 * @MigrateProcessPlugin(
 *   id = "lp_adjustable_columns_item",
 *   handle_multiples = TRUE
 * )
 */
class XXLpAdjustableColumnsItem extends CasLayoutBase {

  /**
   * The OSU Media Embed Service.
   *
   * @var \Drupal\osu_migrations\OsuMediaEmbed
   */
  private OsuMediaEmbed $osuMediaEmbed;

  /**
   * {@inheritDoc}
   */
  public function __construct(array $configuration, $pluginId, $pluginDefinition, UuidInterface $uuid, Connection $db, EntityTypeManagerInterface $entityTypeManager, ConfigFactoryInterface $configFactory, MigrateLookupInterface $migrateLookup, OsuMediaEmbed $osuMediaEmbed) {
    parent::__construct($configuration, $pluginId, $pluginDefinition, $uuid, $db, $entityTypeManager, $configFactory, $migrateLookup);
    $this->osuMediaEmbed = $osuMediaEmbed;
  }

  /**
   * {@inheritDoc}
   */
  public function transform($value, MigrateExecutableInterface $migrate_executable, Row $row, $destination_property) {
    $adjustableColumnsItemIds = $value[0];
    if (!empty($adjustableColumnsItemIds)) {
      $d7_adjustable_columns = $this->getAdjustableColumnsItems($adjustableColumnsItemIds);

      // Create paragraph items.
      $paragraph_items = [];
      foreach ($d7_adjustable_columns as $adjustable_column) {
        // Get the current value.
        $bodyValue = $adjustable_column->field_lp_col_text_value;
        // Pass it to our service to get the new embed value.
        $transformedEmbedCode = $this->osuMediaEmbed->transformEmbedCode($bodyValue);
        $adjustable_column_format = (isset($adjustable_column->field_lp_col_text_format)) ? $adjustable_column->field_lp_col_text_format : "full_html";
        if ($adjustable_column_format == 'filtered_html'){
          $adjustable_column_format = 'basic_html';
        }

        $paragraph_items[] = Paragraph::create([
          'type' => 'osu_accordion_item',
          'field_p_accordion_title' => $adjustable_column->field_lp_col_text_value,
          'field_p_accordion_body' => [
            'value' => $transformedEmbedCode,
            'format' => $adjustable_column_format,
          ],
        ]);
      }

      // Create paragraph section and attach paragraph items.
      $paragraph_section = Paragraph::create([
        'type' => 'paragraph_block_section',
        'field_osu_paragraph_item' => $paragraph_items,
      ]);

      // Return paragraph section which gets attached to the block created by the
      // migration.
      return $paragraph_section;
    }
    return $value;
  }

  /**
   * Query Migration source database for all Paragraph Accordion Bundles.
   *
   * @param mixed $value
   *   The id of the paragraph.
   *
   * @return \Drupal\Core\Database\StatementInterface|null
   *   A prepared statement, or NULL if the query is not valid.
   */
  private function getAdjustableColumnsItems($value) {
    $entity_ids = [];
    $revision_ids = [];
    foreach ($value as $id) {
      $entity_ids[] = $id['value'];
      $revision_ids[] = $id['revision_id'];
    }

    $query = $this->migrateDb->select('field_data_field_lp_col_text', 'lp_col_text');
    $query->leftJoin(
      'field_data_field_lp_col_sm_width',
      'lp_col_sm_width',
      'lp_col_text.entity_id = lp_col_sm_width.entity_id && lp_col_text.revision_id = lp_col_sm_width.revision_id'
    );
    $query->fields('lp_col_text', ['field_lp_col_text_value']);
    $query->fields('lp_col_text', ['field_lp_col_text_format']);
    $query->fields('lp_col_sm_width', ['field_lp_col_sm_width_value']);
    $query->condition('lp_col_text.entity_id', $entity_ids, 'IN');
    $query->condition('lp_col_text.revision_id', $revision_ids, 'IN');
    return $query->execute();
  }

  /**
   * {@inheritDoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition, ?MigrationInterface $migration = NULL) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('uuid'),
      $container->get('database'),
      $container->get('entity_type.manager'),
      $container->get('config.factory'),
      $container->get('migrate.lookup'),
      $container->get('osu_migrations.osu_media_embed')
    );
  }

}
