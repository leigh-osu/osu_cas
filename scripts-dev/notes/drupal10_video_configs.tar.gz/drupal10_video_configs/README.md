# Drupal 7 to Drupal 10 Video Content Type Migration

## Overview
This directory contains configuration files for migrating the "video" content type from Drupal 7 to Drupal 10.

## Generated Files

### Content Type
- `node.type.video.yml` - Video content type definition

### Field Storage (shared configurations)
- `field.storage.node.body.yml` - Body field (text_with_summary)
- `field.storage.node.field_video.yml` - Video file field
- `field.storage.node.field_presenter.yml` - Presenter name (string)
- `field.storage.node.field_affiliation.yml` - Affiliation (string)
- `field.storage.node.publish_date.yml` - Publish date (datetime)
- `field.storage.node.field_owri_tags.yml` - OWRI topics taxonomy
- `field.storage.node.field_coarec_topics.yml` - COAREC topics taxonomy
- `field.storage.node.field_nursery_tags.yml` - Nursery topics taxonomy
- `field.storage.node.field_swd_tags.yml` - SWD topics taxonomy
- `field.storage.node.field_turf_tags.yml` - Turf topics taxonomy
- `field.storage.node.field_veg_tags.yml` - Vegetable topics taxonomy
- `field.storage.node.field_work_area_tags.yml` - Work areas taxonomy
- `field.storage.node.field_event.yml` - Event taxonomy
- `field.storage.node.field_show_on_profile.yml` - User entity reference

### Field Instances (video-specific configurations)
- `field.field.node.video.[field_name].yml` - One file for each field attached to video

### Display Configurations
- `core.entity_form_display.node.video.default.yml` - Edit form layout
- `core.entity_view_display.node.video.default.yml` - Full content display
- `core.entity_view_display.node.video.teaser.yml` - Teaser display

## Important Migration Notes

### Field Type Changes (D7 → D10)

1. **text field** (D7) → **string** (D10)
   - `field_presenter` and `field_affiliation` were plain text fields in D7
   - Mapped to string type in D10 (max_length: 255)

2. **file field** (D7) → **file** (D10)
   - `field_video` remains a file field
   - D7 used Media module integration with schemes (mediaspace, vimeo, youtube)
   - D10 will need Media module or custom integration for remote videos
   - **ACTION REQUIRED**: Install Media module and configure video media types

3. **taxonomy_term_reference** (D7) → **entity_reference** (D10)
   - All taxonomy fields converted to entity_reference type
   - Target type: taxonomy_term
   - Cardinality: -1 (unlimited) for all taxonomy fields

4. **datetime field** (D7) → **datetime** (D10)
   - `publish_date` field
   - D7 used date module with granularity settings
   - D10 uses datetime_type: datetime (includes date and time)

5. **entityreference** (D7) → **entity_reference** (D10)
   - `field_show_on_profile` (references users)
   - D7 used entityreference module
   - D10 uses core entity_reference

### Organic Groups (OG) Fields - NOT MIGRATED

The following D7 fields were **NOT** included in this migration:
- `og_group_ref` - Group reference field
- `group_content_access` - Group content visibility

**REASON**: These are Organic Groups module fields. You need to decide on D10 group solution:
- Option 1: Install Group module (https://www.drupal.org/project/group)
- Option 2: Install OG for D10 if available
- Option 3: Use a different access control mechanism

### Vocabulary Dependencies

The following taxonomy vocabularies must exist in D10:
- `owri` - OWRI topics
- `coarec_topics` - COAREC Topics
- `nursery` - Nursery topics
- `swd` - SWD topics
- `turf` - Turf topics
- `veg` - Vegetable topics
- `work_areas` - Work areas
- `event_list` - Event

**ACTION REQUIRED**: Create these vocabularies before importing the field configs.

### Widget Changes

D7 Widget → D10 Widget mappings:
- `text_textarea_with_summary` → `text_textarea_with_summary` (same)
- `text_textfield` → `string_textfield`
- `media_generic` → `file_generic` (video field will need Media module)
- `multiselect` → `entity_reference_autocomplete` (changed from multiselect widget)
- `entityreference_autocomplete` → `entity_reference_autocomplete`
- `date_popup` → `datetime_default`
- `og_complex` → NOT MIGRATED (need Group module alternative)

### Display Formatters

D7 Formatter → D10 Formatter mappings:
- `text_default` → `text_default` (same)
- `file_rendered` (with view modes) → `file_default` (simpler, may need Media module for advanced display)
- `taxonomy_term_reference_link` → `entity_reference_label`
- `date_default` → `datetime_default`

## Installation Instructions

### 1. Prepare Your D10 Site

```bash
# Enable required core modules
drush en field text file datetime taxonomy path -y
```

### 2. Create Taxonomy Vocabularies

Create vocabularies matching the machine names above. You can do this via:
- Admin UI: Structure → Taxonomy
- Or import vocabulary configs if you have them

### 3. Import Configuration

```bash
# Copy all .yml files to your config sync directory
cp *.yml /path/to/drupal10/config/sync/

# Import the configuration
drush config:import --partial --source=/path/to/drupal10/config/sync/

# Or import individually
drush config:import --partial node.type.video
drush config:import --partial field.storage.node.body
# ... etc
```

### 4. Install Media Module (Recommended)

For proper video handling:
```bash
drush en media media_library -y
```

Create a Video media type and update `field_video` to use it.

### 5. Handle Group/OG Fields

Decide on your grouping strategy and add those fields manually.

### 6. Clear Cache

```bash
drush cr
```

## Data Migration

After importing configs, migrate actual content data using:
- Migrate API with custom migration configs
- Drush migrate commands
- Or Migrate Drupal UI module

Example migrate configuration would map:
```yaml
source:
  plugin: d7_node
  node_type: video

process:
  nid: nid
  vid: vid
  title: title
  uid: uid
  status: status
  created: created
  changed: changed
  body/value: body/value
  body/format: body/format
  field_video: field_video
  field_presenter: field_presenter
  # ... etc
```

## Testing Checklist

After migration:
- [ ] Content type appears in Structure → Content types
- [ ] All fields visible in Manage fields
- [ ] Form display configured correctly (Manage form display)
- [ ] View display configured correctly (Manage display)
- [ ] Test creating a new video node
- [ ] Test editing existing video nodes (after data migration)
- [ ] Verify taxonomy terms display and link correctly
- [ ] Test video file uploads
- [ ] Check permissions for video content type

## Additional Considerations

### Remote Video Support

Your D7 site used Media module with remote video schemes (YouTube, Vimeo). For D10:

1. Install Media module
2. Install video_embed_field or media_entity_video modules
3. Create Video media type
4. Configure oEmbed for YouTube/Vimeo support

### Performance

Consider adding:
- Field caching configurations
- View modes for different display contexts
- Image styles if thumbnails are needed

### Permissions

Don't forget to configure permissions for:
- Create video content
- Edit own/any video content
- Delete own/any video content
- View published/unpublished video content

## Questions or Issues?

Common issues:
1. **Field storage conflicts**: Delete existing fields or rename new ones
2. **Missing dependencies**: Ensure all modules are enabled
3. **Vocabulary not found**: Create vocabularies first
4. **Media integration**: May need custom work for remote videos

## Files Generated: 35 total

- 1 content type config
- 15 field storage configs  
- 15 field instance configs
- 3 display configs
- 1 this README

All configuration follows Drupal 10 best practices and naming conventions.
